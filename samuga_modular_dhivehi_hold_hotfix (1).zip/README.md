# Samuga AI Modular Newsroom

This is the split structure Abdul requested:

- `bot.py` startup only
- `config.py` env vars, constants, sources
- `db.py` PostgreSQL
- `models.py` shared Article model
- `fetchers.py` RSS/latest-page/Telegram/Tavily source ladder
- `scoring.py` freshness, confidence, low-value and duplicate filters
- `brain.py` Claude/Gemini/Tavily/Public Samuga AI brain
- `cards.py` card generation
- `publishing.py` Telegram + Buffer queue
- `website_api.py` website endpoints
- `commands.py` Telegram commands
- `scheduler.py` APScheduler jobs
- `weather.py` weather/MMS hooks
- `state.py` JSON state persistence

Deploy to Railway with the same env vars as the old bot.
